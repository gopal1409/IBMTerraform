# Setup

# Azure CLI
* Download and install the Azure CLI from https://docs.microsoft.com/en-us/cli/azure/install-azure-cli
  * On MacOS, run brew update && brew install azure-cli
  * On Windows, you can download an rund the installer

# Sign in
```
az login
```
